# CS 499 Milestone Four - Database Enhancement

**Student:** Samari Robinson Camacho  
**Artifact:** CS-340 Animal Shelter Dashboard  

## Folder contents

- `Original/` contains the artifact as it existed before the database enhancement.
- `Enhanced/` contains the database-focused enhancement.

## Database improvements

1. MongoDB credentials and settings are read from environment variables instead of being embedded in source code.
2. A unique sparse index protects `animal_id`, while additional indexes support common breed and rescue-profile queries.
3. Create operations require essential fields and reject client-supplied `_id` values.
4. Update operations use an allowlist and prevent changes to immutable identifiers.
5. Delete-one is the default; delete-many requires an explicit confirmation phrase.
6. Dangerous server-side query operators are rejected.
7. Reads support projection, sorting, skip, and a bounded limit.
8. Count and aggregation methods provide efficient database-side processing.
9. Context-manager support ensures that connections can be closed reliably.

## Optional environment variables

```text
MONGODB_USERNAME
MONGODB_PASSWORD
MONGODB_HOST
MONGODB_PORT
MONGODB_DATABASE
MONGODB_COLLECTION
MONGODB_AUTH_SOURCE
```

For a local MongoDB server without authentication, the defaults connect to `mongodb://localhost:27017`, database `aac`, collection `animals`.

## Run

Install dependencies, start MongoDB, open `Enhanced/ProjectTwoDashboard.ipynb`, and run the notebook.
